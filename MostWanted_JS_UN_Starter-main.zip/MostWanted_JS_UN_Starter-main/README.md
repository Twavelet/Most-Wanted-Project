# MostWanted_JS_UN_Starter
Starter code for the Most Wanted JavaScript student project.

## Setup Instructions
- Download the ZIP file to your computer
- Unzip
- Run the `index.html` file in your web browser and click "Start Searching" to run the application

> NOTE: Use the browser's DevTools to debug. The `app` function is the primary entry point for the project.
